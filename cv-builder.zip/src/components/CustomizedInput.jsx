export function CustomizedInput({type, placeholder, value, onChange }) {

    return(
        <input 
        className="border-4 border-blue-200 p-1 px-4 rounded-4xl mb-4 block  focus:border-blue-400 focus:outline-none"
        placeholder={placeholder}
        type={type}
        value={value}
        onChange={onChange}
        />
    )
};