export function Preview({ cv }){
    const personal = cv.personal;
    const skills = cv.skills
    const summary = cv.summary
    return(
        <div>
            <p>name : {personal.name}</p>
            <p>email : {personal.email}</p>
            <p>phone : {personal.tel}</p>
            <p>location : {personal.location}</p>
            <p>skills : 
                <ol>
                    {skills.map(i => (
                        <li key={i}>{i}</li>
                    ))}
                </ol>
            </p>
            <p>summary : {summary}</p>
        </div>
    )
}