import { useState } from 'react'
import './App.css'
import { emptyCV } from './context/cvData'
import { CustomizedInput } from './components/customizedInput'
import { Preview } from './components/Preview'
function App() {

  //State
  const [cv, setCv] = useState(emptyCV)
  const [skillInput, setSkillInput] = useState("")
  const [hobbyInput, setHobbyInput] = useState("")

  //Helper
  const updatePersonal = (field, value) => {
    setCv({ ...cv, personal: { ...cv.personal, [field]: value}});
  }

  const updateField = (field, value) => {
    setCv({ ...cv, [field]: value})
  }

  const addHobby = () => {
    updatePersonal("hobbies", [ ...cv.personal.hobbies, hobbyInput])
    setHobbyInput("")
  }

  const addSkill = () => {
    setCv({ ...cv, skills: [ ...cv.skills, skillInput]})
    setSkillInput("")
  }

  return (
    <>
      <div className="p-8">
        <h1 className='text-2xl font-semibold mb-4'>CV-Builder</h1>
        <CustomizedInput 
        placeholder="Enter your name"
        type="text"
        value={cv.personal.name}
        onChange={(e) => updatePersonal("name", e.target.value)}
        />
        <CustomizedInput 
        placeholder="Enter your email"
        type="email"
        value={cv.personal.email}
        onChange={(e) => updatePersonal("email", e.target.value)}
        />
        <CustomizedInput 
        placeholder="Enter your telephone"
        type="tel"
        value={cv.personal.tel}
        onChange={(e) => updatePersonal("tel", e.target.value)}
        />
        <CustomizedInput 
        placeholder="Enter your location"
        type="text"
        value={cv.personal.location}
        onChange={(e) => updatePersonal("location", e.target.value)}
        />
        <CustomizedInput 
        placeholder="Enter your skill"
        type="text"
        value={skillInput}
        onChange={(e) => setSkillInput(e.target.value)}
        />
        <button
        className='mb-4 bg-blue-300 w-40 h-8 text-sm text-white hover:font-bold font-semibold border-4 rounded-3xl border-blue-300 active:bg-blue-600'
        onClick={() => addSkill()}
        >Click to add skill</button>
        <ul>
          {cv.skills.map((skill) => (
            <li key={skill}>{skill}</li>
          ))}
        </ul>

        <CustomizedInput 
        placeholder="Enter your skill"
        type="text"
        value={hobbyInput}
        onChange={(e) => setHobbyInput(e.target.value)}
        />
        <button
        className='mb-4 bg-blue-300 w-40 h-8 text-sm text-white hover:font-bold font-semibold border-4 rounded-3xl border-blue-300'
        onClick={() => addHobby()}
        >Click to add hobby</button>
        <ul>
          {cv.personal.hobbies.map((hobby) => (
            <li key={hobby}>{hobby}</li>
          ))}
        </ul>
        <input 
        className='pl-4 pr-4 w-full border-4 rounded border-black'
        type="text"
        value={cv.summary}
        placeholder='Summary about you'
        onChange={(e) => updateField("summary", e.target.value)}
        />
        <div className="border-4 rounded border-black flex flex-col">
          <input type="text" placeholder='Enter referer name' />
          <input type="text" placeholder={`Enter referers's company name `}/>
          <input type="text" placeholder='Enter link'/>
        </div>
        <div className="mt-4 text-sm bg-gray-300 p-4 rounded">
          <Preview cv={cv}/>
        </div>
      </div>
    </>
  )
}

export default App
